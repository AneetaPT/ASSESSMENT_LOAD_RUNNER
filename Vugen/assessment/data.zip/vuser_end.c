vuser_end()
{
	return 0;
}